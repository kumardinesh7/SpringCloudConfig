package com.telstra.ccms.ip122;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class RetrieveMapping {

	/**
	 * Retrieve mapping details from mapping.properties
	 * 
	 * @param mappingAttributeName
	 * @return
	 * @throws IOException
	 */
	public String RetrieveMappingDetails(String mappingAttributeName) throws IOException {
		String mappingAttributeValue = null;

		Properties properties = new Properties();
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("mapping.properties");

		if (inputStream != null) {
			properties.load(inputStream);
		}

		mappingAttributeValue = properties.getProperty(mappingAttributeName);
		return mappingAttributeValue;
	}
}