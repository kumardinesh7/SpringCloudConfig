package com.telstra.ccms.ip122;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class RetrieveJsonObject {

	RetrieveMapping retrieveMapping;

	/**
	 * construct JSONObject of resultset
	 * 
	 * @param resultSet
	 * @param mapping
	 * 
	 * @return JSONObject
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	public JSONObject getJSONObject(ResultSet resultSet, boolean mapping) throws SQLException, IOException {
		retrieveMapping = new RetrieveMapping();
		JSONObject jsonObject = new JSONObject();
		ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
		int columnCount = resultSetMetaData.getColumnCount();

		for (int i = 1; i <= columnCount; i++) {
			String columnName = resultSetMetaData.getColumnName(i);

			String mappedColumnName = columnName;
			if (mapping) {
				mappedColumnName = retrieveMapping.RetrieveMappingDetails(columnName);
			}

			if (resultSetMetaData.getColumnType(i) == java.sql.Types.ARRAY) {
				jsonObject.put(mappedColumnName,
						resultSet.getArray(columnName) == null ? "" : resultSet.getArray(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.BIGINT) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getInt(columnName)) == null ? "" : resultSet.getInt(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.BOOLEAN) {
				jsonObject.put(mappedColumnName, String.valueOf(resultSet.getBoolean(columnName)) == null ? ""
						: resultSet.getBoolean(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.BLOB) {
				jsonObject.put(mappedColumnName,
						resultSet.getBlob(columnName) == null ? "" : resultSet.getBlob(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.DOUBLE) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getDouble(columnName)) == null ? "" : resultSet.getDouble(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.FLOAT) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getFloat(columnName)) == null ? "" : resultSet.getFloat(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.INTEGER) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getInt(columnName)) == null ? "" : resultSet.getInt(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.NVARCHAR) {
				jsonObject.put(mappedColumnName,
						resultSet.getNString(columnName) == null ? "" : resultSet.getNString(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.VARCHAR) {
				jsonObject.put(mappedColumnName,
						resultSet.getString(columnName) == null ? "" : resultSet.getString(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.TINYINT) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getInt(columnName)) == null ? "" : resultSet.getInt(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.SMALLINT) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getInt(columnName)) == null ? "" : resultSet.getInt(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.DATE) {
				jsonObject.put(mappedColumnName,
						resultSet.getDate(columnName) == null ? "" : resultSet.getDate(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.TIMESTAMP) {
				jsonObject.put(mappedColumnName,
						resultSet.getTimestamp(columnName) == null ? "" : resultSet.getTimestamp(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.NUMERIC) {
				jsonObject.put(mappedColumnName,
						String.valueOf(resultSet.getLong(columnName)) == null ? "" : resultSet.getLong(columnName));
			} else if (resultSetMetaData.getColumnType(i) == java.sql.Types.CHAR) {
				jsonObject.put(mappedColumnName,
						resultSet.getString(columnName) == null ? "" : resultSet.getString(columnName));
			} else {
				jsonObject.put(mappedColumnName,
						resultSet.getObject(columnName) == null ? "" : resultSet.getObject(columnName));
			}
		}

		return jsonObject;
	}
}
