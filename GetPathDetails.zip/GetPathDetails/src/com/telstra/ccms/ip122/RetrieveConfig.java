package com.telstra.ccms.ip122;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class RetrieveConfig {

	/**
	 * Retrieve configuration details from config.properties
	 * 
	 * @param configAttributeName
	 * @return
	 * @throws IOException
	 */
	public String RetrieveConfigDetails(String configAttributeName) throws IOException {
		String configAttributeValue = null;

		Properties properties = new Properties();
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("config.properties");

		if (inputStream != null) {
			properties.load(inputStream);
		}

		configAttributeValue = properties.getProperty(configAttributeName);
		return configAttributeValue;
	}
}