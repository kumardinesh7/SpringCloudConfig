package com.telstra.ccms.ip122;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.apache.log4j.Logger;
import org.json.JSONArray;

import com.telstra.ccms.util.ExecuteQuery;

@Path("/getPathDetails")
public class GetPathDetails {

	ResultSet resultSet;

	RetrieveJsonObject retrieveJsonObject;
	ExecuteQuery executeQuery;
	RetrieveConfig retrieveConfig;

	JSONArray jsonArray;
	JSONObject jsonObject;
	JSONObject jsonObjectServices;
	JSONArray jsonArrayUDA;

	String serviceId;

	String errorCode1;
	String errorCode2;
	String errorCode3;
	String errorCode4;

	String errorCodeDesc1;
	String errorCodeDesc2;
	String errorCodeDesc3;
	String errorCodeDesc4;

	private static Logger logger = Logger.getLogger(GetPathDetails.class);

	/**
	 * Construct JSON response for GET request
	 * 
	 * @param getServiceId
	 * @param userId
	 * @param userPassword
	 * 
	 * @return JSON
	 */
	@GET
	public String getJSON(@DefaultValue("") @QueryParam("serviceId") String getServiceId,
			@DefaultValue("") @QueryParam("userId") String userId,
			@DefaultValue("") @QueryParam("userPassword") String userPassword) {
		executeQuery = new ExecuteQuery();
		retrieveJsonObject = new RetrieveJsonObject();
		retrieveConfig = new RetrieveConfig();
		resultSet = null;

		logger.info("Requested Service Id: " + getServiceId);
		serviceId = getServiceId;

		try {
			errorCode1 = retrieveConfig.RetrieveConfigDetails("errorCode1");
			errorCode2 = retrieveConfig.RetrieveConfigDetails("errorCode2");
			errorCode3 = retrieveConfig.RetrieveConfigDetails("errorCode3");
			errorCode4 = retrieveConfig.RetrieveConfigDetails("errorCode4");

			errorCodeDesc1 = retrieveConfig.RetrieveConfigDetails("errorCodeDesc1");
			errorCodeDesc2 = retrieveConfig.RetrieveConfigDetails("errorCodeDesc2");
			errorCodeDesc3 = retrieveConfig.RetrieveConfigDetails("errorCodeDesc3");
			errorCodeDesc4 = retrieveConfig.RetrieveConfigDetails("errorCodeDesc4");

		} catch (Exception e) {
			jsonObject = new JSONObject();
			jsonObject.put("Error Message", "IP122_1002:Inventory Internal error");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.error(sw.toString());
			return jsonObject.toString();
		}

		if (serviceId.equals("") || serviceId == null) {
			jsonObject = new JSONObject();
			jsonObject.put("Error Message", errorCode4 + ":" + errorCodeDesc4);
			logger.error(errorCode4 + ":" + errorCodeDesc4);
			return jsonObject.toString();
		}

		try {
			if (!userId.equals(retrieveConfig.RetrieveConfigDetails("userId"))
					|| !userPassword.equals(retrieveConfig.RetrieveConfigDetails("userPassword"))) {
				jsonObject = new JSONObject();
				jsonObject.put("Error Message", errorCode3 + ":" + errorCodeDesc3);
				logger.error(errorCode3 + ":" + errorCodeDesc3);
				return jsonObject.toString();
			}
		} catch (Exception e) {
			jsonObject = new JSONObject();
			jsonObject.put("Error Message", errorCode2 + ":" + errorCodeDesc2);
			logger.error(errorCode2 + ":" + errorCodeDesc2);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.error(sw.toString());
			return jsonObject.toString();
		}

		jsonArray = new JSONArray();
		try {
			String query = retrieveConfig.RetrieveConfigDetails("queryService");
			query = query.replace("serviceId", "'" + serviceId + "'");
			resultSet = executeQuery.executeSelect(query);

			if (!resultSet.next()) {
				jsonObject = new JSONObject();
				jsonObject.put("Error Message", errorCode1 + ":" + errorCodeDesc1 + " " + serviceId);
				logger.error(errorCode1 + ":" + errorCodeDesc1 + " " + serviceId);
				return jsonObject.toString();
			}

			jsonObject = new JSONObject();
			jsonObject = retrieveJsonObject.getJSONObject(resultSet, true);

			jsonObjectServices = getChildServices();
			jsonArrayUDA = getUDADetails();
			if (jsonObjectServices.length() > 0)
				jsonObject.put("childServices", jsonObjectServices);
			if (jsonArrayUDA.length() > 0)
				jsonObject.put("UDA", jsonArrayUDA);

			jsonArray.put(jsonObject);
		} catch (Exception e) {
			jsonObject = new JSONObject();
			jsonObject.put("Error Message", errorCode2 + ":" + errorCodeDesc2);
			logger.error(errorCode2 + ":" + errorCodeDesc2);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.error(sw.toString());
			return jsonObject.toString();
		}

		logger.info(jsonArray.toString().replace("\"{", "{").replace("}\"", "}").replace("\\\"", "\"").replace("\\\\\"", "\\\""));
		return jsonArray.toString().replace("\"{", "{").replace("}\"", "}").replace("\\\"", "\"").replace("\\\\\"", "\\\"");
	}

	/**
	 * Construct a JSONObject of ChildServices
	 * 
	 * @return JSONObject of ChildServices
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	private JSONObject getChildServices() throws SQLException, IOException {
		JSONArray jsonArrayServices = new JSONArray();
		JSONObject jsonObjectServicesFinal = new JSONObject();

		String queryChildServices = retrieveConfig.RetrieveConfigDetails("queryChildServices");
		queryChildServices = queryChildServices.replace("serviceId", "'" + serviceId + "'");
		resultSet = executeQuery.executeSelect(queryChildServices);

		while (resultSet.next()) {
			JSONObject jsonObjectServices = new JSONObject();
			jsonObjectServices = retrieveJsonObject.getJSONObject(resultSet, true);
			jsonArrayServices.put(new org.json.JSONObject(jsonObjectServices.toString()));
		}
		jsonObjectServicesFinal = new JSONObject();
		if (jsonArrayServices.length() > 0)
			jsonObjectServicesFinal.put("childService", jsonArrayServices);

		return jsonObjectServicesFinal;
	}

	/**
	 * Construct a JSONArray of UDA Details
	 * 
	 * @return JSONArray of UDA Details
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	private JSONArray getUDADetails() throws SQLException, IOException {
		JSONArray jsonArrayUDA = new JSONArray();

		String queryUDADetails = retrieveConfig.RetrieveConfigDetails("queryUDADetails");
		queryUDADetails = queryUDADetails.replace("serviceId", "'" + serviceId + "'");
		resultSet = executeQuery.executeSelect(queryUDADetails);

		while (resultSet.next()) {
			JSONObject jsonObjectUDA = new JSONObject();
			jsonObjectUDA = retrieveJsonObject.getJSONObject(resultSet, false);
			jsonArrayUDA.put(new org.json.JSONObject(jsonObjectUDA.toString()));
		}

		return jsonArrayUDA;
	}
}