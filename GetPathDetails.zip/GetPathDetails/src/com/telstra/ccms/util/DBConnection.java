package com.telstra.ccms.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.telstra.ccms.ip122.RetrieveConfig;

import oracle.jdbc.pool.OracleDataSource;

public class DBConnection {

	/**
	 * Create connection with database
	 * 
	 * @return connection
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	public static Connection getDBConnection() throws SQLException, IOException {
		Connection connection = null;
		RetrieveConfig retrieveConfig = new RetrieveConfig();

		String jdbcUrl = retrieveConfig.RetrieveConfigDetails("dbURL");
		String userId = retrieveConfig.RetrieveConfigDetails("dbUserId");
		String password = retrieveConfig.RetrieveConfigDetails("dbPassword");

		OracleDataSource ds;
		ds = new OracleDataSource();
		ds.setURL(jdbcUrl);
		connection = ds.getConnection(userId, password);

		return connection;
	}
}