package com.telstra.ccms.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ExecuteQuery {

	/**
	 * Execute select query on the connection
	 * 
	 * @param selectQuery
	 * 
	 * @return resultset
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	public ResultSet executeSelect(String selectQuery) throws SQLException, IOException {
		Connection connection = DBConnection.getDBConnection();

		Statement statement = null;
		ResultSet resultSet = null;
		statement = connection.createStatement();
		resultSet = statement.executeQuery(selectQuery);

		return resultSet;
	}
}
