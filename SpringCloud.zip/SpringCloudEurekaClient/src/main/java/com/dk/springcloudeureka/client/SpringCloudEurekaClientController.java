package com.dk.springcloudeureka.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SpringCloudEurekaClientController {

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/")
	public String getResponse() {
		String url = "http://SpringCloudEurekaServer/";
		return restTemplate.getForObject(url, String.class);
	}
}
