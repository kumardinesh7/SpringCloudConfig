package com.dk.springcloudeureka.server;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringCloudEurekaServerController {

	@GetMapping("/")
	public String getResponse() {
		return "this is message from Eureka Server";
	}
}
