package com.dk.springboot.actuator;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.actuate.info.Info.Builder;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.stereotype.Component;

@Component
public class SpringBootActuatorInfoContributor implements InfoContributor {

	@Override
	public void contribute(Builder builder) {
		Map<String, String> mapInfo = new HashMap<>();
		mapInfo.put("name", "Spring Boot Actuator");
		mapInfo.put("description", "Spring Boot Actuator Implementation");
		builder.withDetail("app", mapInfo);
	}
}
